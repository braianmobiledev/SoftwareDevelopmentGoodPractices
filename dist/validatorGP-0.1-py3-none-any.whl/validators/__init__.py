from .verificadores import Verificador, Autenticador, Validador, Cache, Filtro_IP

verificador = Verificador()
autenticador = Autenticador()
validador = Validador()
filtro_ip = Filtro_IP()
cache = Cache()